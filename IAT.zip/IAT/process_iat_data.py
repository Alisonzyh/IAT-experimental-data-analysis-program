import pandas as pd
import numpy as np
import os
import ast

def process_iat_data(file_path):
    # 读取CSV文件
    df = pd.read_csv(file_path)
    
    # 提取试验编号（从文件名中获取）
    trial_num = os.path.basename(file_path).split('_')[1].split('.')[0]
    
    # 获取性别和年龄
    gender = df[df['task'] == 'demographics']['response'].iloc[0]
    age = ast.literal_eval(df[df['task'] == 'demographics']['response'].iloc[1])['Q0']
    
    # 处理反应时数据
    # 只选择IAT测试阶段的数据
    iat_data = df[df['task'] == 'IAT flowerInsect'].copy()
    
    # 将RT限制在300-3000ms之间
    iat_data.loc[iat_data['rt'] < 300, 'rt'] = 300
    iat_data.loc[iat_data['rt'] > 3000, 'rt'] = 3000
    
    # 对RT进行自然对数转换
    iat_data['log_rt'] = np.log(iat_data['rt'])
    
    # 计算两个测验阶段的平均反应时
    phase1_mean = iat_data.iloc[19:27]['log_rt'].mean()
    phase2_mean = iat_data.iloc[35:59]['log_rt'].mean()
    
    # 计算IAT效应分数
    iat_score = phase2_mean - phase1_mean
    
    return {
        '试验编号': trial_num,
        '性别': gender,
        '年龄': age,
        'IAT效应分': iat_score
    }

# 获取data文件夹中的所有CSV文件
data_folder = 'data'  # data文件夹的路径
files = [f for f in os.listdir(data_folder) if f.startswith('_') and f.endswith('.csv')]

results = []

for file in files:
    file_path = os.path.join(data_folder, file)  # 构建完整的文件路径
    try:
        result = process_iat_data(file_path)
        results.append(result)
        print(f'成功处理文件：{file}')
    except Exception as e:
        print(f'处理文件 {file} 时出错：{str(e)}')

# 创建汇总DataFrame并保存
summary_df = pd.DataFrame(results)
summary_df.to_csv('IAT数据汇总.csv', index=False, encoding='utf-8-sig')
print(f'共处理 {len(results)} 个文件，数据已保存到 IAT数据汇总.csv')